package Harjoitus;
/** T�m� on luokka, jossa on p��ohjelmametodi.
 * 
 * @author Arttu Nikkinen 			x103871@student.uwasa.fi
 * @version	1.0
 * @since 1.0
 */
public class HotelliJ�rjestelm�
{

	public static void main(String[] args)
	{
		new HotelliUi();	//Luodaan uusi HotelliUi-olio
	}

}
